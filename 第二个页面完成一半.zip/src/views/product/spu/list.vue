<template>
  <div>spuList</div>
</template>

<script>
export default {
  name: 'Spu',
}
</script>

