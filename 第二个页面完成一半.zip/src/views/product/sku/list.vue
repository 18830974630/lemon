<template>
  <div>SkuList</div>
</template>

<script>
export default {
  name: 'Sku',
}
</script>


